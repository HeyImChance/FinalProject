package chesswars.Pieces;

//Created by Ashley Dodson using Abstract class by Michael Scott

import chesswars.Piece;
import chesswars.Position;

//November 2016

public class Knight extends Piece{
    
    public Knight(int r, int c, boolean isRed){
        super(c, r, isRed);
        canJump = true;
    }
    
    public boolean testMove(Position p){
        Position pos = new Position(this.c, this.r);
        Position test = pos.getVector(p);

        if (test.getR() == -2 && test.getC() == -1)
            return true;
        else if (test.getR() == -2 && test.getC() == 1)
            return true;
        else if (test.getR() == 2 && test.getC() == 1)
            return true;
        else if (test.getR() == 2 && test.getC() == -1)
            return true;
        else if (test.getR() == -1 && test.getC() == -2)
            return true;
        else if (test.getR() == -1 && test.getC() == 2)
            return true;
        else if (test.getR() == 1 && test.getC() == 2)
            return true;
        else if (test.getR() == 1 && test.getC() == -2)
            return true;
        return false;
    }
}
