// *Note possibly deprecated class
package chesswars;

/**
 *
 * @author Michael scott
 */
public class Focus {
    
    private ChessImageView cv;
    
    public Focus(ChessImageView cv){
        this.cv = cv;
    }
    
    public void setFocus(ChessImageView cv){
        this.cv = cv;
    }
    
    public ChessImageView getFocus(){
        return cv;
    }
    
}
