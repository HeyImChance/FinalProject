package chesswars;

import javafx.scene.layout.Pane;

/*
 *  @Author: Michael Scott
 */

public abstract class Piece {
    
    //Instance variables
    protected int r;
    protected int c;    
    protected boolean isRed;
    protected boolean firstMove;
    protected boolean canJump = false;
    
    /*
    Public constrctor for the abstract qualities of a piece
    @param: int, int, boolean
    @return: Piece
    */
    public Piece(int r, int c, boolean isRed){
        this.r = r;
        this.c = c;
        this.isRed = isRed;
        this.firstMove = true;
    }
    
    /*
    Getters and Setters
    */
    public int getR(){
        return r;
    }
    
    public int getC(){
        return c;
    }
    
    public boolean canJump(){
        return canJump;
    }
    
    public boolean isRed(){
        return isRed;
    }
    
    public void setR(int r){
        this.r = r;
    }
    
    public void setC(int c){
        this.c = c;
    }
    
    public void setCanJump(boolean jump){
        this.canJump = jump;
    }
    
    public void takeFirstMove(){
        this.firstMove = false;
    }
    
    /*
    Abstract method that must be replaced by every concrete
    implementation of a piece.  Given a Position this method will
    determine if this piece can move to that Position from its 
    current Position.
    @param: Position
    @return: boolean
    */
    public abstract boolean testMove(Position p);
    
}
