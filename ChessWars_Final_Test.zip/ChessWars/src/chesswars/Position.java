package chesswars;

/*
 *  @Author: Michael Scott
 */

public class Position {
    
    //instance variables
    private int r;
    private int c;
    
    public Position(){
        
    }
    
    /*
    Public constructor for a Position
    @param: int, int
    @return: Position
    */
    public Position(int c, int r){
        this.r = r;
        this.c = c;
    }
    
    /*
    Getters and Setters
    */
    public int getR(){
        return r;
    }
    
    public int getC(){
        return c;
    }
    
    public void setR(int r){
        this.r = r;
    }
    
    public void setC(int c){
        this.c = c;
    }
    
    /*
    Given a Position, this method returns a Vector from its current
    position to the the paramater Position. 
    @param: Position
    @return: Position
    */
    public Position getVector(Position p1){
        return new Position(p1.c - c, p1.r - r);
    }
}
