package chesswars.Pieces;

import chesswars.Piece;
import chesswars.Piece;
import chesswars.Position;
import chesswars.Position;

/**
 *
 * @author Michael
 */
public class Lancer extends Piece{
    private int movement;
    
    public Lancer(int r, int c, boolean isRed){
        super(c, r, isRed);
        
        if(isRed){
            movement = 1;
        }
        else{
            movement = -1;
        }
    }
    
    public void takeFirstMove(){
        firstMove = false;
    }
    
    public boolean testMove(Position p){
        Position pos = new Position(this.c, this.r);
        Position test = pos.getVector(p);

        if (test.getR() == (-1 * movement) && test.getC() == 0)
            return true;
        else if(test.getR() == (-2 * movement) && test.getC() == 0){
            return true;
        }
        return false;
    }
}
