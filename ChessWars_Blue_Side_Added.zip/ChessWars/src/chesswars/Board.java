package chesswars;

import static chesswars.ChessWars.root;
import java.util.List;
import java.util.Stack;
import javafx.geometry.Pos;
import javafx.scene.image.Image;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;

/**
 *
 * @author Michael scott
 */
public class Board {

    static GridPane root;
    static ChessStackPane[][] board;
    static ChessImageView focus;
    public List<ChessImageView> pieces;

    public Board() {

        root = new GridPane();
        root.setAlignment(Pos.CENTER);
        final int size = 8;
        board = new ChessStackPane[size][size];
        pieces = new Stack<>();
        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) {
                ChessStackPane square = new ChessStackPane();
                String color;
                if ((row + col) % 2 == 0) {
                    color = "lightgrey";
                } else {
                    color = "darkgrey";
                }
                square.setStyle("-fx-background-color: " + color + ";");
                square.setRow(row);
                square.setCol(col);
                square.setEmpty(true);
                square.possibleMove = false;
                root.add(square, col, row);
                board[row][col] = square;

            }
        }

        for (int i = 0; i < size; i++) {
            root.getColumnConstraints().add(new ColumnConstraints(60));
            root.getRowConstraints().add(new RowConstraints(60));
        }

    }

    public GridPane getGridPane() {
        return root;
    }
    
    public void setFocus(ChessImageView cv){
        focus = cv;
    }
    
    public ChessImageView getFocus(){
        return focus;
    }

    public void rePaintBoard() {

        root.getChildren().clear();
        int count = 0;
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                root.getChildren().add(count, board[j][i]);
                board[j][i].setEmpty(true);
                count++;
            }
        }

        for (int i = 0; i < pieces.size(); i++) {
            if (pieces.isEmpty()) {
                break;
            } else {
                ChessImageView temp = pieces.get(i);
                root.getChildren().remove(temp);
                root.add(temp, temp.content.getC(), temp.content.getR());
                board[temp.content.getC()][temp.content.getR()].setEmpty(false);
            }
        }
    }

    public void writePossibleMoves(Piece p) {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                Position attempt = new Position(j, i);
                if (p.testMove(attempt) && board[j][i].testIsEmpty()) {
                    PossibleMoveImageView pm = new PossibleMoveImageView(new Image("legalMove.PNG", 50, 50, true, true, false), j, i, this);
                    root.add(pm, j, i);
                    board[j][i].possibleMove = true;
                }
            }
        }
    }
    
}
