package chesswars;

import chesswars.Pieces.Pawn;
import chesswars.Pieces.Rook;
import chesswars.Pieces.Knight;
import chesswars.Pieces.Bishop;
import chesswars.Pieces.Queen;
import chesswars.Pieces.King;
import java.io.IOException;
import java.util.List;
import java.util.Stack;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author Michael scott
 * Edited and modified by Ashley Dodson November 2016
 */
public class ChessWars extends Application {
    
    
    static GridPane root;
    static ChessStackPane[][] board;
    static ChessImageView focus;
    static List<ChessImageView> pieces;

   public void start(Stage primaryStage) {

        Board universe = new Board();
        
        
        primaryStage.setScene(new Scene(universe.getGridPane(), 800, 800));
        primaryStage.show();
        
        //RED SIDE PIECES

        Pawn p1 = new Pawn(0, 6, true);
        ChessImageView cv11 = new ChessImageView(new Image("Pawn2.PNG", 50, 50, true, true, false), p1, universe);
        universe.getGridPane().add(cv11, 0, 6);
        universe.pieces.add(cv11);
        universe.board[0][6].isEmpty = false;
        
        Pawn p2 = new Pawn(1, 6, true);
        ChessImageView cv12 = new ChessImageView(new Image("Pawn2.PNG", 50, 50, true, true, false), p2, universe);
        universe.getGridPane().add(cv12, 1, 6);
        universe.pieces.add(cv12);
        universe.board[1][6].isEmpty = false;
        
        Pawn p3 = new Pawn(2, 6, true);
        ChessImageView cv13 = new ChessImageView(new Image("Pawn2.PNG", 50, 50, true, true, false), p3, universe);
        universe.getGridPane().add(cv13, 2, 6);
        universe.pieces.add(cv13);
        universe.board[2][6].isEmpty = false;
        
        Pawn p4 = new Pawn(3, 6, true);
        ChessImageView cv14 = new ChessImageView(new Image("Pawn2.PNG", 50, 50, true, true, false), p4, universe);
        universe.getGridPane().add(cv14, 3, 6);
        universe.pieces.add(cv14);
        universe.board[3][6].isEmpty = false;
        
        Pawn p5 = new Pawn(4, 6, true);
        ChessImageView cv15 = new ChessImageView(new Image("Pawn2.PNG", 50, 50, true, true, false), p5, universe);
        universe.getGridPane().add(cv15, 4, 6);
        universe.pieces.add(cv15);
        universe.board[4][6].isEmpty = false;
        
        Pawn p6 = new Pawn(5, 6, true);
        ChessImageView cv16 = new ChessImageView(new Image("Pawn2.PNG", 50, 50, true, true, false), p6, universe);
        universe.getGridPane().add(cv16, 5, 6);
        universe.pieces.add(cv16);
        universe.board[5][6].isEmpty = false;
        
        Pawn p7 = new Pawn(6, 6, true);
        ChessImageView cv17 = new ChessImageView(new Image("Pawn2.PNG", 50, 50, true, true, false), p7, universe);
        universe.getGridPane().add(cv17, 6, 6);
        universe.pieces.add(cv17);
        universe.board[6][6].isEmpty = false;
        
        Pawn p8 = new Pawn(7, 6, true);
        ChessImageView cv18 = new ChessImageView(new Image("Pawn2.PNG", 50, 50, true, true, false), p8, universe);
        universe.getGridPane().add(cv18, 7, 6);
        universe.pieces.add(cv18);
        universe.board[7][6].isEmpty = false;
        
        King KI = new King(4, 7, true);
        ChessImageView cv2 = new ChessImageView(new Image("King.png", 50, 50, true, true, false), KI, universe);
        universe.getGridPane().add(cv2, 4, 7);
        universe.pieces.add(cv2);
        universe.board[4][7].isEmpty = false;
        
        Queen QU = new Queen(3, 7, true);
        ChessImageView cv1 = new ChessImageView(new Image("Queen.PNG", 50, 50, true, true, false), QU, universe);
        universe.getGridPane().add(cv1, 3, 7);
        universe.pieces.add(cv1);
        universe.board[3][7].isEmpty = false;

        Bishop Lb = new Bishop(2, 7, true);
        ChessImageView cv3 = new ChessImageView(new Image("Bishop.png", 50, 50, true, true, false), Lb, universe);
        universe.getGridPane().add(cv3, 2, 7);
        universe.pieces.add(cv3);
        universe.board[2][7].isEmpty = false;
        
        Bishop Rb = new Bishop(5, 7, true);
        ChessImageView cv5 = new ChessImageView(new Image("Bishop.png", 50, 50, true, true, false), Rb, universe);
        universe.getGridPane().add(cv5, 5, 7);
        universe.pieces.add(cv5);
        universe.board[5][7].isEmpty = false;
        
        Knight Rk = new Knight(6, 7, true);
        ChessImageView cv21 = new ChessImageView(new Image("Knight.PNG", 50, 50, true, true, false), Rk, universe);
        universe.getGridPane().add(cv21, 6, 7);
        universe.pieces.add(cv21);
        universe.board[6][7].isEmpty = false;
        
        Knight Lk = new Knight(1, 7, true);
        ChessImageView cv20 = new ChessImageView(new Image("Knight.PNG", 50, 50, true, true, false), Lk, universe);
        universe.getGridPane().add(cv20, 1, 7);
        universe.pieces.add(cv20);
        universe.board[1][7].isEmpty = false;
        
        Rook Lr = new Rook(0, 7, true);
        ChessImageView cv4 = new ChessImageView(new Image("Rook.png", 50, 50, true, true, false), Lr, universe);
        universe.getGridPane().add(cv4, 0, 7);
        universe.pieces.add(cv4);
        universe.board[0][7].isEmpty = false;
        
        Rook Rr = new Rook(7, 7, true);
        ChessImageView cv6 = new ChessImageView(new Image("Rook.png", 50, 50, true, true, false), Rr, universe);
        universe.getGridPane().add(cv6, 7, 7);
        universe.pieces.add(cv6);
        universe.board[7][7].isEmpty = false;
        
        
        //BLUE SIDE PIECES
        
        Pawn bp1 = new Pawn(0, 1, false);
        ChessImageView blueP1 = new ChessImageView(new Image("Pawn2_blue.png", 50, 50, true, true, false), bp1, universe);
        universe.getGridPane().add(blueP1, 0, 1);
        universe.pieces.add(blueP1);
        universe.board[0][1].isEmpty = false;
        
        Pawn bp2 = new Pawn(1, 1, false);
        ChessImageView blueP2 = new ChessImageView(new Image("Pawn2_blue.png", 50, 50, true, true, false), bp2, universe);
        universe.getGridPane().add(blueP2, 1, 1);
        universe.pieces.add(blueP2);
        universe.board[1][1].isEmpty = false;
        
        Pawn bp3 = new Pawn(2, 1, false);
        ChessImageView blueP3 = new ChessImageView(new Image("Pawn2_blue.png", 50, 50, true, true, false), bp3, universe);
        universe.getGridPane().add(blueP3, 2, 1);
        universe.pieces.add(blueP3);
        universe.board[2][1].isEmpty = false;
        
        Pawn bp4 = new Pawn(3, 1, false);
        ChessImageView blueP4 = new ChessImageView(new Image("Pawn2_blue.png", 50, 50, true, true, false), bp4, universe);
        universe.getGridPane().add(blueP4, 3, 1);
        universe.pieces.add(blueP4);
        universe.board[3][1].isEmpty = false;
        
        Pawn bp5 = new Pawn(4, 1, false);
        ChessImageView blueP5 = new ChessImageView(new Image("Pawn2_blue.png", 50, 50, true, true, false), bp5, universe);
        universe.getGridPane().add(blueP5, 4, 1);
        universe.pieces.add(blueP5);
        universe.board[4][1].isEmpty = false;
        
        Pawn bp6 = new Pawn(5, 1, false);
        ChessImageView blueP6 = new ChessImageView(new Image("Pawn2_blue.png", 50, 50, true, true, false), bp6, universe);
        universe.getGridPane().add(blueP6, 5, 1);
        universe.pieces.add(blueP6);
        universe.board[5][1].isEmpty = false;
        
        Pawn bp7 = new Pawn(6, 1, false);
        ChessImageView blueP7 = new ChessImageView(new Image("Pawn2_blue.png", 50, 50, true, true, false), bp7, universe);
        universe.getGridPane().add(blueP7, 6, 1);
        universe.pieces.add(blueP7);
        universe.board[6][1].isEmpty = false;
        
        Pawn bp8 = new Pawn(7, 1, false);
        ChessImageView blueP8 = new ChessImageView(new Image("Pawn2_blue.png", 50, 50, true, true, false), bp8, universe);
        universe.getGridPane().add(blueP8, 7, 1);
        universe.pieces.add(blueP8);
        universe.board[7][1].isEmpty = false;
        
        Queen blueQ = new Queen(4, 0, false);
        ChessImageView blueQcv = new ChessImageView(new Image("Queen_blue.png", 50, 50, true, true, false), blueQ, universe);
        universe.getGridPane().add(blueQcv, 4, 0);
        universe.pieces.add(blueQcv);
        universe.board[4][0].isEmpty = false;
    } 

}
