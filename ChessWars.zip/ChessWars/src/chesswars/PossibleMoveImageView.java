/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package chesswars;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

 public class PossibleMoveImageView extends ImageView {

        Image standard;
        private int r;
        private int c;

        public PossibleMoveImageView(Image standard, int c, int r) {
            super(standard);
            this.standard = standard;
            this.r = r;
            this.c = c;

            setOnMouseClicked(event -> {
                /*
                root.getChildren().remove(focus);
                savePieces();
                deletePossibleMoves();
                focus.getPiece().setR(this.r);
                focus.getPiece().setC(this.c);
                root.add(focus, this.c, this.r);
                focus = null;
                        */
            });
        }

        public int getR() {
            return r;
        }

        public int getC() {
            return c;
        }

        public void setR(int r) {
            this.r = r;
        }

        public void setC(int c) {
            this.c = c;
        }

        public Image getContent() {
            return standard;
        }
    }
