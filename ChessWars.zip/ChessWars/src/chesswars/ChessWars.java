/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package chesswars;

import java.io.IOException;
import java.util.List;
import java.util.Stack;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author Michael scott
 */
public class ChessWars extends Application {
    
    
    static GridPane root;
    static ChessStackPane[][] board;
    static ChessImageView focus;
    static List<ChessImageView> pieces;

   public void start(Stage primaryStage) {

        Board universe = new Board();
        
        
        primaryStage.setScene(new Scene(universe.getGridPane(), 800, 800));
        primaryStage.show();

        Piece r = new Piece();
        r.setC(4);
        r.setR(7);
        Focus cv1Focus = new Focus(null);
        
        ChessImageView cv1 = new ChessImageView(new Image("Capture.PNG", 50, 50, true, true, false), r, universe);
        universe.getGridPane().add(cv1, 4, 7);



    } 

}
