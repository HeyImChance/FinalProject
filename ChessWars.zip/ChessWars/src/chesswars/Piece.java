/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package chesswars;

import javafx.scene.layout.Pane;

public class Piece {
    

    private int r;
    private int c;
    
    
    
    
    
    public int getR(){
        return r;
    }
    
    public int getC(){
        return c;
    }
    
    public void setR(int r){
        this.r = r;
    }
    
    public void setC(int c){
        this.c = c;
    }
    
    public boolean testMove(Position p){
        Position pos = new Position(this.c, this.r);
        Position test = pos.getVector(p);
        if (test.getR() == this.r && test.getC() == this.c)
            return false;
        else if (test.getR() == -1 && test.getC() == 0)
            return true;
        return false;
    }
}
