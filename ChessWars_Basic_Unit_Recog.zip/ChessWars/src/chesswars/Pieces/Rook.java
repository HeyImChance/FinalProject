package chesswars.Pieces;

//Created by Ashley Dodson using Abstract class by Michael Scott

import chesswars.Piece;
import chesswars.Position;

//November 2016

public class Rook extends Piece{
    
    public Rook(int r, int c, boolean isRed){
        super(c, r, isRed);
    }
    
    public boolean testMove(Position p){
        Position pos = new Position(this.c, this.r);
        Position test = pos.getVector(p);

        if (test.getR() == this.r && test.getC() == this.c)
            return false;
        else if (test.getR() != 0 && test.getC() == 0)
            return true;
        else if (test.getR() == 0 && test.getC() != 0)
            return true;
        return false;
    }
}
