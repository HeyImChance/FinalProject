package chesswars.Pieces;

import chesswars.Piece;
import chesswars.Position;

/**
 *
 * @author Michael
 */
public class Pawn extends Piece{
    public Pawn(int r, int c, boolean isRed){
        super(c, r, isRed);
    }
    
    public void takeFirstMove(){
        firstMove = false;
    }
    
    public boolean testMove(Position p){
        Position pos = new Position(this.c, this.r);
        Position test = pos.getVector(p);

        if (test.getR() == this.r && test.getC() == this.c)
            return false;
        else if ((test.getR() == -2 && test.getC() == 0) && this.firstMove){
            return true;
        }
        else if (test.getR() == -1 && test.getC() == 0)
            return true;
        return false;
    }
}
