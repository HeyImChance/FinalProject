/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package chesswars;

import javafx.scene.layout.Pane;

public abstract class Piece {
    

    protected int r;
    protected int c;    
    protected boolean isRed;
    protected boolean firstMove;
    
    public Piece(int r, int c, boolean isRed){
        this.r = r;
        this.c = c;
        this.isRed = isRed;
        this.firstMove = true;
    }
    
    public int getR(){
        return r;
    }
    
    public int getC(){
        return c;
    }
    
    public boolean isRed(){
        return isRed;
    }
    
    public void setR(int r){
        this.r = r;
    }
    
    public void setC(int c){
        this.c = c;
    }
    
    public void takeFirstMove(){
        firstMove = false;
    }
    
    public abstract boolean testMove(Position p);
    
}
