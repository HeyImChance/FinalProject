package chesswars;

import javafx.scene.layout.Pane;

public abstract class Piece {
    
    protected int r;
    protected int c;    
    protected boolean isRed;
    protected boolean firstMove;
    protected boolean canJump = false;
    
    public Piece(int r, int c, boolean isRed){
        this.r = r;
        this.c = c;
        this.isRed = isRed;
        this.firstMove = true;
    }
    
    public int getR(){
        return r;
    }
    
    public int getC(){
        return c;
    }
    
    public boolean canJump(){
        return canJump;
    }
    
    public boolean isRed(){
        return isRed;
    }
    
    public void setR(int r){
        this.r = r;
    }
    
    public void setC(int c){
        this.c = c;
    }
    
    public void setCanJump(boolean jump){
        this.canJump = jump;
    }
    
    public void takeFirstMove(){
        this.firstMove = false;
    }
    
    public abstract boolean testMove(Position p);
    
}
