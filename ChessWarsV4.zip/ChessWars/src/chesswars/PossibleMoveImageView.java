package chesswars;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;

/*
 *  @Author: Michael Scott
 */

 public class PossibleMoveImageView extends ImageView {

        //Instance variables
        ChessImageView content;
        Board chessBoard;
        Focus f;
        Image standard;
        private int r;
        private int c;

        /*
        Public constructor for a PossibleMoveImageView which
        includes a Mouse Listener.
        @param: Image, int, int, board
        @return: PossibleMoveImageView
        */
        public PossibleMoveImageView(Image standard, int c, int r, Board b) {
            super(standard);
            this.standard = standard;
            this.r = r;
            this.c = c;
            chessBoard = b;
            
            /*
            Mouse Listener that includes functionality for when a 
            PossibleMoveImageView is clicked to remove the current
            Focus from the current Board and to place it back onto the 
            Board where the PossibleMoveImageView was. If there was a 
            piece there as well then that piece will be removed from the
            boards stack of pieces.  The method then Re Paints the board
            with all current pieces in the Board's stack.
            */
            setOnMouseClicked(event -> {
                
                PossibleMoveImageView pm = (PossibleMoveImageView) event.getSource();
                GridPane gp = (GridPane) pm.getParent();
                gp.getChildren().remove(chessBoard.getFocus());
                ChessStackPane[][] squares = chessBoard.getBoard();
                squares[chessBoard.getFocus().getPiece().c][chessBoard.getFocus().getPiece().r].content = null;
                chessBoard.getFocus().getPiece().setR(this.r);
                chessBoard.getFocus().getPiece().setC(this.c);
                gp.add(chessBoard.getFocus(), this.c, this.r);
                squares[this.c][this.r].setContent(chessBoard.getFocus());
                chessBoard.setFocus(null);
                chessBoard.rePaintBoard();
            });
        }
        
        /*
        Getters and Setters
        */
        public int getR() {
            return r;
        }

        public int getC() {
            return c;
        }

        public void setR(int r) {
            this.r = r;
        }

        public void setC(int c) {
            this.c = c;
        }

        public ChessImageView getContent() {
            return content;
        }
        
        public void setContent(ChessImageView cv){
            content = cv;
        }
    }
