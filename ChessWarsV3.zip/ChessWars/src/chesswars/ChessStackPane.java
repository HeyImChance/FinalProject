
package chesswars;

import javafx.scene.layout.StackPane;

/*
 *  @Author: Michael Scott
 */

 public class ChessStackPane extends StackPane {

        //Instance Variables
        ChessImageView content;
        Boolean possibleMove;
        Boolean isRed = false;
        boolean isEmpty = true;
        int row;
        int col;
        
        public ChessStackPane() {
            super();
        }
        
        
        /*
        Getters and Setters
        */
        
        public boolean testIsEmpty(){
            return isEmpty;
        }
        
        public void setSide(boolean set){
            isRed = set;
        }
        
        public boolean isRed(){
            return isRed;
        }
        
        public void setEmpty(boolean isEmpty){
            this.isEmpty = isEmpty;
        }

        public void setRow(int row) {
            this.row = row;
        }

        public void setCol(int col) {
            this.col = col;
        }

        public void setPossibleMove(boolean pm) {
            possibleMove = pm;
        }
        
        public ChessImageView getContent(){
            return content;
        }
        
        public void setContent(ChessImageView param){
            content = param;
        }
    }
