package chesswars;

import java.util.List;
import java.util.Stack;
import javafx.geometry.Pos;
import javafx.scene.image.Image;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;

/**
 *
 * @author Michael scott
 * @purpose Defines an 8x8 board for Chess Wars
 */
public class Board {

    //instance variables
    static GridPane root;
    static ChessStackPane[][] board;
    static ChessImageView focus;
    public List<ChessImageView> pieces;

    public Board() {

        /*
        The Board uses a grid pane as its parent container
        called root
         */
        root = new GridPane();
        root.setAlignment(Pos.CENTER);
        final int size = 8;

        /*
        the Board is composed of 64 stack panes
        and a handle to each will be stored in the 
        two dimensional array called board as well as
        each piece being stored in a stack called pieces
         */
        board = new ChessStackPane[size][size];
        pieces = new Stack<>();
        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) {
                ChessStackPane square = new ChessStackPane();
                String color;
                if ((row + col) % 2 == 0) {
                    color = "lightgrey";
                } else {
                    color = "darkgrey";
                }
                square.setStyle("-fx-background-color: " + color + ";");
                square.setRow(row);
                square.setCol(col);
                square.setEmpty(true);
                square.setSide(true);
                square.possibleMove = false;
                root.add(square, col, row);
                board[row][col] = square;
            }
        }

        //set the column and constraints for the Board
        for (int i = 0; i < size; i++) {
            root.getColumnConstraints().add(new ColumnConstraints(60));
            root.getRowConstraints().add(new RowConstraints(60));
        }

    }

    /*
    This method removes a piece from the stack that holds
    all the pieces for the Board.
    @param: Piece
    @return: void
     */
    public void removePiece(ChessImageView removal) {
        pieces.remove(removal);
    }

    /*
    Returns the handle to the Board
    @param: void
    @return: GridPane
     */
    public GridPane getGridPane() {
        return root;
    }

    /*
    Sets the focus for the board which is a ChessImageView
    that represents a piece on the board.
    @param: ChessImageView
    @return: void
     */
    public void setFocus(ChessImageView cv) {
        focus = cv;
    }

    /*
    Returns the current focus of the board which is a 
    ChessImageView that represents a piece on the board.
    @param: void
    @return: ChessImageView
     */
    public ChessImageView getFocus() {
        return focus;
    }

    public ChessStackPane[][] getBoard() {
        return board;
    }
    
    public List<ChessImageView> getPieces(){
        return pieces;
    }

    /*
    Repaint the board by tearing down all the squares
    and then replacing them.  Then paints all pieces in the 
    instance variable stack back onto the board.
    @param: void
    @return: void
     */
    public void rePaintBoard() {

        root.getChildren().clear();
        int count = 0;
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                root.getChildren().add(count, board[j][i]);
                board[j][i].setEmpty(true);
                count++;
            }
        }

        for (int i = 0; i < pieces.size(); i++) {
            if (pieces.isEmpty()) {
                break;
            } else {
                ChessImageView temp = pieces.get(i);
                root.getChildren().remove(temp);
                root.add(temp, temp.content.getC(), temp.content.getR());
                board[temp.content.getC()][temp.content.getR()].setEmpty(false);
                board[temp.content.getC()][temp.content.getR()].setSide(temp.content.isRed());
            }
        }
    }

    /*
    Given a piece, draw all the possible moves of the piece
    onto the board using PossibleMoveImageView's.
    @param: Piece
    @return: void
     */
    public void writePossibleMoves(Piece p) {

        //Code for determining possible moves of jump pieces
        if (p.canJump()) {
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    Position attempt = new Position(j, i);

                    if (p.testMove(attempt) && board[j][i].testIsEmpty()) {
                        PossibleMoveImageView pm = new PossibleMoveImageView(new Image("CanMove.PNG", 50, 50, true, true, false), j, i, this);
                        root.add(pm, j, i);
                        board[j][i].possibleMove = true;
                    } else if (p.testMove(attempt) && !board[j][i].testIsEmpty()) {
                        if (p.isRed() != board[j][i].getContent().getPiece().isRed()) {
                            PossibleMoveImageView pm = new PossibleMoveImageView(new Image("CanCapture.PNG", 50, 50, true, true, false), j, i, this);
                            root.add(pm, j, i);
                            board[j][i].possibleMove = true;
                        }
                    }
                }
            }
        } else {
            // Code for determining possible moves along the West orthogonal
            for (int i = p.getC(); i >= 0; i--) {
                Position attempt = new Position(i, p.getR());

                if (p.testMove(attempt) && board[i][p.getR()].getContent() == null) {
                    PossibleMoveImageView pm = new PossibleMoveImageView(new Image("CanMove.PNG", 50, 50, true, true, false), i, p.getR(), this);
                    root.add(pm, i, p.getR());
                    board[i][p.getR()].possibleMove = true;
                } else if (p.testMove(attempt) && board[i][p.getR()].getContent().getPiece().isRed() != p.isRed()) {
                    PossibleMoveImageView pm = new PossibleMoveImageView(new Image("CanCapture.PNG", 50, 50, true, true, false), i, p.getR(), this);
                    root.add(pm, i, p.getR());
                    board[i][p.getR()].possibleMove = true;
                    break;
                } else if (p.testMove(attempt) && board[i][p.getR()].getContent().getPiece().isRed() == p.isRed()) {
                    break;
                }
            }

            //Code determing possible moves along the East orthogonal
            for (int i = p.getC(); i < 8; i++) {
                Position attempt = new Position(i, p.getR());

                if (p.testMove(attempt) && board[i][p.getR()].getContent() == null) {
                    PossibleMoveImageView pm = new PossibleMoveImageView(new Image("CanMove.PNG", 50, 50, true, true, false), i, p.getR(), this);
                    root.add(pm, i, p.getR());
                    board[i][p.getR()].possibleMove = true;
                } else if (p.testMove(attempt) && board[i][p.getR()].getContent().getPiece().isRed != p.isRed()) {
                    PossibleMoveImageView pm = new PossibleMoveImageView(new Image("CanCapture.PNG", 50, 50, true, true, false), i, p.getR(), this);
                    root.add(pm, i, p.getR());
                    board[i][p.getR()].possibleMove = true;
                    break;
                } else if (p.testMove(attempt) && board[i][p.getR()].getContent().getPiece().isRed == p.isRed()) {
                    break;
                }
            }

            //Code determing possible moves along the North orthogonal
            for (int i = p.getR(); i >= 0; i--) {
                Position attempt = new Position(p.getC(), i);

                if (p.testMove(attempt) && board[p.getC()][i].getContent() == null) {
                    PossibleMoveImageView pm = new PossibleMoveImageView(new Image("CanMove.PNG", 50, 50, true, true, false), p.getC(), i, this);
                    root.add(pm, p.getC(), i);
                    board[p.getC()][i].possibleMove = true;
                } else if (p.testMove(attempt) && board[p.getC()][i].getContent().getPiece().isRed != p.isRed()) {
                    PossibleMoveImageView pm = new PossibleMoveImageView(new Image("CanCapture.PNG", 50, 50, true, true, false), p.getC(), i, this);
                    root.add(pm, p.getC(), i);
                    board[p.getC()][i].possibleMove = true;
                    break;
                } else if (p.testMove(attempt) && board[p.getC()][i].getContent().getPiece().isRed == p.isRed()) {
                    break;
                }
            }

            //Code for determining possible moves along the South orthogonal
            for (int i = p.getR(); i < 8; i++) {
                Position attempt = new Position(p.getC(), i);

                if (p.testMove(attempt) && board[p.getC()][i].getContent() == null) {
                    PossibleMoveImageView pm = new PossibleMoveImageView(new Image("CanMove.PNG", 50, 50, true, true, false), p.getC(), i, this);
                    root.add(pm, p.getC(), i);
                    board[p.getC()][i].possibleMove = true;
                } else if (p.testMove(attempt) && board[p.getC()][i].getContent().getPiece().isRed != p.isRed()) {
                    PossibleMoveImageView pm = new PossibleMoveImageView(new Image("CanCapture.PNG", 50, 50, true, true, false), p.getC(), i, this);
                    root.add(pm, p.getC(), i);
                    board[p.getC()][i].possibleMove = true;
                    break;
                } else if (p.testMove(attempt) && board[p.getC()][i].getContent().getPiece().isRed == p.isRed()) {
                    break;
                }
            }

            //Code for determining possible moves along the North West diagonal
            int count = p.getR();
            for (int i = p.getC(); i >= 0; i--) {
                Position attempt = new Position(i, count);

                if (count >= 0 && count < 8 && p.testMove(attempt) && board[i][count].getContent() == null) {
                    PossibleMoveImageView pm = new PossibleMoveImageView(new Image("CanMove.PNG", 50, 50, true, true, false), i, count, this);
                    root.add(pm, i, count);
                    board[i][count].possibleMove = true;
                } else if (count < 8 && count >= 0 && p.testMove(attempt) && board[i][count].getContent().getPiece().isRed != p.isRed()) {
                    PossibleMoveImageView pm = new PossibleMoveImageView(new Image("CanCapture.PNG", 50, 50, true, true, false), i, count, this);
                    root.add(pm, i, count);
                    board[i][count].possibleMove = true;
                    break;
                } else if (count < 8 && count >= 0 && p.testMove(attempt) && board[i][count].getContent().getPiece().isRed == p.isRed()) {
                    break;
                }
                count--;
            }

            //Code for determing possible moves along the North East diagonal
            count = p.getR();
            for (int i = p.getC(); i < 8; i++) {
                Position attempt = new Position(i, count);

                if (count < 8 && count >= 0 && p.testMove(attempt) && board[i][count].getContent() == null) {
                    PossibleMoveImageView pm = new PossibleMoveImageView(new Image("CanMove.PNG", 50, 50, true, true, false), i, count, this);
                    root.add(pm, i, count);
                    board[i][count].possibleMove = true;
                } else if (count >= 0 && count < 8 && p.testMove(attempt) && board[i][count].getContent().getPiece().isRed != p.isRed()) {
                    PossibleMoveImageView pm = new PossibleMoveImageView(new Image("CanCapture.PNG", 50, 50, true, true, false), i, count, this);
                    root.add(pm, i, count);
                    board[i][count].possibleMove = true;
                    break;
                } else if (count <= 8 && count > 0 && p.testMove(attempt) && board[i][count].getContent().getPiece().isRed == p.isRed()) {
                    break;
                }
                count--;
            }

            //Code for determining possible moves along the South West diagonal
            count = p.getR();
            for (int i = p.getC(); i >= 0; i--) {
                Position attempt = new Position(i, count);

                if (count < 8 && count >= 0 && p.testMove(attempt) && board[i][count].getContent() == null) {
                    PossibleMoveImageView pm = new PossibleMoveImageView(new Image("CanMove.PNG", 50, 50, true, true, false), i, count, this);
                    root.add(pm, i, count);
                    board[i][count].possibleMove = true;
                } else if (count >= 0 && count < 8 && p.testMove(attempt) && board[i][count].getContent().getPiece().isRed != p.isRed()) {
                    PossibleMoveImageView pm = new PossibleMoveImageView(new Image("CanCapture.PNG", 50, 50, true, true, false), i, count, this);
                    root.add(pm, i, count);
                    board[i][count].possibleMove = true;
                    break;
                } else if (count < 8 && count > 0 && p.testMove(attempt) && board[i][count].getContent().getPiece().isRed == p.isRed()) {
                    break;
                }
                count++;
            }

            //Code for determining possible moves along the South East diagonal
            count = p.getR();
            for (int i = p.getC(); i < 8; i++) {
                Position attempt = new Position(i, count);

                if (count < 8 && count >= 0 && p.testMove(attempt) && board[i][count].getContent() == null) {
                    PossibleMoveImageView pm = new PossibleMoveImageView(new Image("CanMove.PNG", 50, 50, true, true, false), i, count, this);
                    root.add(pm, i, count);
                    board[i][count].possibleMove = true;
                } else if (count >= 0 && count < 8 && p.testMove(attempt) && board[i][count].getContent().getPiece().isRed != p.isRed()) {
                    PossibleMoveImageView pm = new PossibleMoveImageView(new Image("CanCapture.PNG", 50, 50, true, true, false), i, count, this);
                    root.add(pm, i, count);
                    board[i][count].possibleMove = true;
                    break;
                } else if (count < 8 && count > 0 && p.testMove(attempt) && board[i][count].getContent().getPiece().isRed == p.isRed()) {
                    break;
                }
                count++;
            }
        }
    }
}
