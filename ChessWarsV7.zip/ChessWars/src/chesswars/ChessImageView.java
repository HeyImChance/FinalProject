package chesswars;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;

/*
 *  @Author: Michael Scott
 */

 public class ChessImageView extends ImageView {

        //instance variables
        Piece content;
        Boolean focus;
        Board chessBoard;

        /*
        Public constructor for a ChessImageView which includes a mouse
        listener
        @param: Image, Piece, Board
        @return: ChessImageView
        */
        public ChessImageView(Image image, Piece content, Board universe) {
            super(image);
            this.content = content;
            focus = false;
            chessBoard = universe;

            /*
            Mouse Listener that includes functionality for when
            a ChessImageView is clicked to write all the possible
            moves of the piece that this ChessImageView represents
            onto the current board.
            */
            setOnMouseClicked(event -> {
                
                //System.out.println("Here it is");
                if (chessBoard.getFocus() != null) {
                    ChessImageView cv = (ChessImageView) event.getSource();
                    GridPane gp = (GridPane) cv.getParent();
                    gp.getChildren().remove(cv);
                    chessBoard.rePaintBoard();
                    chessBoard.setFocus(null);
                } 
                else {
                    chessBoard.setFocus(this);
                    universe.writePossibleMoves(content);
                }
            });
        }

        /*
        Getter for the piece this ChessImageView represents
        @param: void
        @return: Piece
        */
        public Piece getPiece() {
            return content;
        }
    }
