package chesswars;



import chesswars.Pieces.Bishop;
import chesswars.Pieces.Dragon;
import chesswars.Pieces.GoldGeneral;
import chesswars.Pieces.King;
import chesswars.Pieces.Knight;
import chesswars.Pieces.Lancer;
import chesswars.Pieces.Pawn;
import chesswars.Pieces.Queen;
import chesswars.Pieces.Rook;
import chesswars.Pieces.SilverGeneral;
import chesswars.Pieces.Sorceress;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.image.Image;

/**
 * Controller class for the second chess pane
 */
public class Chess2Controller {
    
    Board universe = new Board();

    /**
     * Event handler fired when the user requests the board
     *
     * @param event the event that triggered the handler.
     */
    @FXML
    void setupBoard(ActionEvent event) {
        
        
        //RED SIDE PIECES

             //RED SIDE PIECES

        buildPieces(8, 0, 6, true);
        buildPieces(11, 1, 6, true);
        buildPieces(1, 2, 6, true);
        buildPieces(9, 3, 6, true);
        buildPieces(1, 4, 6, true);
        buildPieces(10, 5, 6, true);
        buildPieces(1, 6, 6, true);
        buildPieces(8, 7, 6, true);
        buildPieces(5, 4, 7, true);
        buildPieces(7, 5, 7, true);
        
        //BLUE SIDE PIECES
        
        buildPieces(2, 0, 0, false);
        buildPieces(2, 7, 0, false);
        buildPieces(4, 1, 0, false);
        buildPieces(5, 3, 0, false);
        buildPieces(3, 4, 0, false);
        buildPieces(6, 5, 0, false);
        buildPieces(9, 2, 1, false);
        buildPieces(11, 5, 1, false);
        
                //key call which switches the main pane to the setup game board
        ChessNavigator.getMainController().setChess(universe.getGridPane());
    } 
   
    public void buildPieces(int type, int row, int col, boolean red){
       ChessImageView built = null;
       
       //Pawn
       if(type == 1){
           Pawn builder = new Pawn(row, col, red);
           if(red){
               built = new ChessImageView(new Image("Swordsman.png", 50, 50, true, true, false), builder, universe);
           }
           else{
               built = new ChessImageView(new Image("Swordsman_blue.png", 50, 50, true, true, false), builder, universe);
           }
       }
       //Rook
       else if(type == 2){
           Rook builder = new Rook(row, col, red);
           if(red){
               built = new ChessImageView(new Image("Rook2.png", 50, 50, true, true, false), builder, universe);
           }
           else{
               built = new ChessImageView(new Image("Rook2_blue.png", 50, 50, true, true, false), builder, universe);
           }
       }
       //Bishop
       else if(type == 3){
           Bishop builder = new Bishop(row, col, red);
           if(red){
               built = new ChessImageView(new Image("Bishop.png", 50, 50, true, true, false), builder, universe);
           }
           else{
               built = new ChessImageView(new Image("Bishop_blue.png", 50, 50, true, true, false), builder, universe);
           }
       }
       //Knight
       else if(type == 4){
           Knight builder = new Knight(row, col, red);
           if(red){
               built = new ChessImageView(new Image("Knight.PNG", 50, 50, true, true, false), builder, universe);
           }
           else{
               built = new ChessImageView(new Image("Knight.PNG", 50, 50, true, true, false), builder, universe);
           }
       }
       //Queen
       else if(type == 5){
           Queen builder = new Queen(row, col, red);
           if(red){
               built = new ChessImageView(new Image("Queen.PNG", 50, 50, true, true, false), builder, universe);
           }
           else{
               built = new ChessImageView(new Image("Queen_blue.png", 50, 50, true, true, false), builder, universe);
           }
       }
       //King
       else if(type == 6){
           King builder = new King(row, col, red);
           if(red){
               built = new ChessImageView(new Image("King.png", 50, 50, true, true, false), builder, universe);
           }
           else{
               built = new ChessImageView(new Image("King_blue.png", 50, 50, true, true, false), builder, universe);
           }
       }
       //Gold General
       else if(type == 7){
           GoldGeneral builder = new GoldGeneral(row, col, red);
           if(red){
               built = new ChessImageView(new Image("G_General.png", 50, 50, true, true, false), builder, universe);
           }
           else{
               built = new ChessImageView(new Image("G_General_blue.png", 50, 50, true, true, false), builder, universe);
           }
       }
       //Lancer
       else if(type == 8){
           Lancer builder = new Lancer(row, col, red);
           if(red){
               built = new ChessImageView(new Image("Pawn2.PNG", 50, 50, true, true, false), builder, universe);
           }
           else{
               built = new ChessImageView(new Image("Pawn2_blue.png", 50, 50, true, true, false), builder, universe);
           }
       }
       //Silver General
       else if(type == 9){
           SilverGeneral builder = new SilverGeneral(row, col, red);
           if(red){
               built = new ChessImageView(new Image("S_General.png", 50, 50, true, true, false), builder, universe);
           }
           else{
               built = new ChessImageView(new Image("S_General_blue.png", 50, 50, true, true, false), builder, universe);
           }
       }
       //Dragon
       else if(type == 10){
           Dragon builder = new Dragon(row, col, red);
           if(red){
               built = new ChessImageView(new Image("Dragon.png", 50, 50, true, true, false), builder, universe);
           }
           else{
               built = new ChessImageView(new Image("Dragon_blue.png", 50, 50, true, true, false), builder, universe);
           }
       }
       //Sorceress
       else if(type == 11){
           Sorceress builder = new Sorceress(row, col, red);
           if(red){
               built = new ChessImageView(new Image("Sorceress.png", 50, 50, true, true, false), builder, universe);
           }
           else{
               built = new ChessImageView(new Image("Sorceress_blue.png", 50, 50, true, true, false), builder, universe);
           }
       }
       
       universe.getGridPane().add(built, row, col);
       universe.pieces.add(built);
       universe.board[row][col].isEmpty = false;
       universe.board[row][col].content = built;
   
        
    }

}