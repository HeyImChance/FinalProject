package chesswars;

public class Bishop extends Piece{
    
    public Bishop(int r, int c){
        super(c, r);
    }
    
    public boolean testMove(Position p){
        Position pos = new Position(this.c, this.r);
        Position test = pos.getVector(p);

        if (test.getR() == this.r && test.getC() == this.c)
            return false;
        else if (test.getR() == -1 && test.getC() == -1)
            return true;
        else if (test.getR() == 1 && test.getC() == 1)
            return true;
        else if (test.getR() == -1 && test.getC() == 1)
            return true;
        else if (test.getR() == 1 && test.getC() == -1)
            return true;
        return false;
    }
}
