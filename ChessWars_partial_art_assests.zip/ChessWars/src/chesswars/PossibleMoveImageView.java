/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package chesswars;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;

 public class PossibleMoveImageView extends ImageView {

        ChessImageView content;
        Board chessBoard;
        Focus f;
        Image standard;
        private int r;
        private int c;

        public PossibleMoveImageView(Image standard, int c, int r, Board b) {
            super(standard);
            this.standard = standard;
            this.r = r;
            this.c = c;
            chessBoard = b;
            setOnMouseClicked(event -> {
                
                PossibleMoveImageView pm = (PossibleMoveImageView) event.getSource();
                GridPane gp = (GridPane) pm.getParent();
                gp.getChildren().remove(chessBoard.getFocus());
                chessBoard.getFocus().getPiece().setR(this.r);
                chessBoard.getFocus().getPiece().setC(this.c);
                gp.add(chessBoard.getFocus(), this.c, this.r);
                chessBoard.setFocus(null);
                chessBoard.rePaintBoard();
            });
        }

        public int getR() {
            return r;
        }

        public int getC() {
            return c;
        }

        public void setR(int r) {
            this.r = r;
        }

        public void setC(int c) {
            this.c = c;
        }

        public ChessImageView getContent() {
            return content;
        }
        
        public void setContent(ChessImageView cv){
            content = cv;
        }
    }
