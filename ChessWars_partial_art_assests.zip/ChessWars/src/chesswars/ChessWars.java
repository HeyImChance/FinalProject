package chesswars;

import chesswars.Pieces.Pawn;
import chesswars.Pieces.*;
import java.io.IOException;
import java.util.List;
import java.util.Stack;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 * @author Michael scott
 * Edited and modified by Ashley Dodson November 2016
 */
public class ChessWars extends Application {
    
    static GridPane root;
    static ChessStackPane[][] board;
    static ChessImageView focus;
    static List<ChessImageView> pieces;
    Board universe = new Board();
    
    /*
    This runs the game, as well as inserting the pieces. 
    See the function; buildPieces; for more information.
    */
    public void start(Stage primaryStage) {
        primaryStage.setScene(new Scene(universe.getGridPane(), 800, 800));
        primaryStage.show();
        
        //RED SIDE PIECES

        buildPieces(1, 0, 6, true);
        buildPieces(1, 1, 6, true);
        buildPieces(1, 2, 6, true);
        buildPieces(8, 3, 6, true);
        buildPieces(8, 4, 6, true);
        buildPieces(8, 5, 6, true);
        buildPieces(1, 6, 6, true);
        buildPieces(1, 7, 6, true);
        buildPieces(5, 4, 7, true);
        buildPieces(7, 5, 7, true);
        
        //BLUE SIDE PIECES
        
        buildPieces(2, 0, 0, false);
        buildPieces(2, 7, 0, false);
        buildPieces(4, 1, 0, false);
        buildPieces(5, 3, 0, false);
        buildPieces(3, 4, 0, false);
        buildPieces(6, 5, 0, false);
    } 
   
    public void buildPieces(int type, int row, int col, boolean red){
       ChessImageView built = null;
       
       //Pawn
       if(type == 1){
           Pawn builder = new Pawn(row, col, red);
           if(red){
               built = new ChessImageView(new Image("Swordsman.png", 50, 50, true, true, false), builder, universe);
           }
           else{
               built = new ChessImageView(new Image("Swordsman_blue.png", 50, 50, true, true, false), builder, universe);
           }
       }
       //Rook
       else if(type == 2){
           Rook builder = new Rook(row, col, red);
           if(red){
               built = new ChessImageView(new Image("Rook2.png", 50, 50, true, true, false), builder, universe);
           }
           else{
               built = new ChessImageView(new Image("Rook2_blue.png", 50, 50, true, true, false), builder, universe);
           }
       }
       //Bishop
       else if(type == 3){
           Bishop builder = new Bishop(row, col, red);
           if(red){
               built = new ChessImageView(new Image("Bishop.png", 50, 50, true, true, false), builder, universe);
           }
           else{
               built = new ChessImageView(new Image("Bishop_blue.png", 50, 50, true, true, false), builder, universe);
           }
       }
       //Knight
       else if(type == 4){
           Knight builder = new Knight(row, col, red);
           if(red){
               built = new ChessImageView(new Image("Knight.PNG", 50, 50, true, true, false), builder, universe);
           }
           else{
               built = new ChessImageView(new Image("Knight.PNG", 50, 50, true, true, false), builder, universe);
           }
       }
       //Queen
       else if(type == 5){
           Queen builder = new Queen(row, col, red);
           if(red){
               built = new ChessImageView(new Image("Queen.PNG", 50, 50, true, true, false), builder, universe);
           }
           else{
               built = new ChessImageView(new Image("Queen_blue.png", 50, 50, true, true, false), builder, universe);
           }
       }
       //King
       else if(type == 6){
           King builder = new King(row, col, red);
           if(red){
               built = new ChessImageView(new Image("King.png", 50, 50, true, true, false), builder, universe);
           }
           else{
               built = new ChessImageView(new Image("King.png", 50, 50, true, true, false), builder, universe);
           }
       }
       //Gold General
       else if(type == 7){
           GoldGeneral builder = new GoldGeneral(row, col, red);
           if(red){
               built = new ChessImageView(new Image("G_General.png", 50, 50, true, true, false), builder, universe);
           }
           else{
               built = new ChessImageView(new Image("G_General_blue.png", 50, 50, true, true, false), builder, universe);
           }
       }
       //Lancer
       else if(type == 8){
           Lancer builder = new Lancer(row, col, red);
           if(red){
               built = new ChessImageView(new Image("Pawn2.PNG", 50, 50, true, true, false), builder, universe);
           }
           else{
               built = new ChessImageView(new Image("Pawn2_blue.png", 50, 50, true, true, false), builder, universe);
           }
       }
       
       universe.getGridPane().add(built, row, col);
       universe.pieces.add(built);
       universe.board[row][col].isEmpty = false;
       universe.board[row][col].content = built;
   }
}
