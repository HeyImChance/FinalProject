package chesswars;

import java.io.IOException;
import java.util.List;
import java.util.Stack;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author Michael scott
 * Edited and modified by Ashley Dodson November 2016
 */
public class ChessWars extends Application {
    
    
    static GridPane root;
    static ChessStackPane[][] board;
    static ChessImageView focus;
    static List<ChessImageView> pieces;

   public void start(Stage primaryStage) {

        Board universe = new Board();
        
        
        primaryStage.setScene(new Scene(universe.getGridPane(), 800, 800));
        primaryStage.show();
        
        //RED SIDE PIECES

        Pawn p1 = new Pawn(0, 6);
        ChessImageView cv11 = new ChessImageView(new Image("Pawn2.PNG", 50, 50, true, true, false), p1, universe);
        universe.getGridPane().add(cv11, 0, 6);
        universe.pieces.add(cv11);
        
        Pawn p2 = new Pawn(1, 6);
        ChessImageView cv12 = new ChessImageView(new Image("Pawn2.PNG", 50, 50, true, true, false), p2, universe);
        universe.getGridPane().add(cv12, 1, 6);
        universe.pieces.add(cv12);
        
        Pawn p3 = new Pawn(2, 6);
        ChessImageView cv13 = new ChessImageView(new Image("Pawn2.PNG", 50, 50, true, true, false), p3, universe);
        universe.getGridPane().add(cv13, 2, 6);
        universe.pieces.add(cv13);
        
        Pawn p4 = new Pawn(3, 6);
        ChessImageView cv14 = new ChessImageView(new Image("Pawn2.PNG", 50, 50, true, true, false), p4, universe);
        universe.getGridPane().add(cv14, 3, 6);
        universe.pieces.add(cv14);
        
        Pawn p5 = new Pawn(4, 6);
        ChessImageView cv15 = new ChessImageView(new Image("Pawn2.PNG", 50, 50, true, true, false), p5, universe);
        universe.getGridPane().add(cv15, 4, 6);
        universe.pieces.add(cv15);
        
        Pawn p6 = new Pawn(5, 6);
        ChessImageView cv16 = new ChessImageView(new Image("Pawn2.PNG", 50, 50, true, true, false), p6, universe);
        universe.getGridPane().add(cv16, 5, 6);
        universe.pieces.add(cv16);
        
        Pawn p7 = new Pawn(6, 6);
        ChessImageView cv17 = new ChessImageView(new Image("Pawn2.PNG", 50, 50, true, true, false), p7, universe);
        universe.getGridPane().add(cv17, 6, 6);
        universe.pieces.add(cv17);
        
        Pawn p8 = new Pawn(7, 6);
        ChessImageView cv18 = new ChessImageView(new Image("Pawn2.PNG", 50, 50, true, true, false), p8, universe);
        universe.getGridPane().add(cv18, 7, 6);
        universe.pieces.add(cv18);
        
        King KI = new King(4, 7);
        ChessImageView cv2 = new ChessImageView(new Image("King.png", 50, 50, true, true, false), KI, universe);
        universe.getGridPane().add(cv2, 4, 7);
        universe.pieces.add(cv2);
        
        Queen QU = new Queen(3, 7);
        ChessImageView cv1 = new ChessImageView(new Image("Queen.PNG", 50, 50, true, true, false), QU, universe);
        universe.getGridPane().add(cv1, 3, 7);
        universe.pieces.add(cv1);

        Bishop Lb = new Bishop(2, 7);
        ChessImageView cv3 = new ChessImageView(new Image("Bishop.png", 50, 50, true, true, false), Lb, universe);
        universe.getGridPane().add(cv3, 2, 7);
        universe.pieces.add(cv3);
        
        Bishop Rb = new Bishop(5, 7);
        ChessImageView cv5 = new ChessImageView(new Image("Bishop.png", 50, 50, true, true, false), Rb, universe);
        universe.getGridPane().add(cv5, 5, 7);
        universe.pieces.add(cv5);
        
        Knight Rk = new Knight(6, 7);
        ChessImageView cv21 = new ChessImageView(new Image("Knight.PNG", 50, 50, true, true, false), Rk, universe);
        universe.getGridPane().add(cv21, 6, 7);
        universe.pieces.add(cv21);
        
        Knight Lk = new Knight(1, 7);
        ChessImageView cv20 = new ChessImageView(new Image("Knight.PNG", 50, 50, true, true, false), Lk, universe);
        universe.getGridPane().add(cv20, 1, 7);
        universe.pieces.add(cv20);
        
        Rook Lr = new Rook(0, 7);
        ChessImageView cv4 = new ChessImageView(new Image("Rook.png", 50, 50, true, true, false), Lr, universe);
        universe.getGridPane().add(cv4, 0, 7);
        universe.pieces.add(cv4);
        
        Rook Rr = new Rook(7, 7);
        ChessImageView cv6 = new ChessImageView(new Image("Rook.png", 50, 50, true, true, false), Rr, universe);
        universe.getGridPane().add(cv6, 7, 7);
        universe.pieces.add(cv6);
        
        
        //BLUE SIDE PIECES
    } 

}
