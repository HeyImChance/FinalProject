/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package chesswars;

/**
 *
 * @author Michael scott
 */
public class Focus {
    
    private ChessImageView cv;
    
    public Focus(ChessImageView cv){
        this.cv = cv;
    }
    
    public void setFocus(ChessImageView cv){
        this.cv = cv;
    }
    
    public ChessImageView getFocus(){
        return cv;
    }
    
}
