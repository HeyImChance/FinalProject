/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package chesswars;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;

 public class ChessImageView extends ImageView {

        Piece content;
        Boolean focus;
        Board chessBoard;

        public ChessImageView(Image image, Piece content, Board universe) {
            super(image);
            this.content = content;
            focus = false;
            chessBoard = universe;

            setOnMouseClicked(event -> {
                
                if (chessBoard.getFocus() != null) {
                    //deletePossibleMoves();
                    ChessImageView cv = (ChessImageView) event.getSource();
                    GridPane gp = (GridPane) cv.getParent();
                    gp.getChildren().remove(cv);
                    chessBoard.rePaintBoard();
                    chessBoard.setFocus(null);

                } else {
                    chessBoard.setFocus(this);
                    universe.writePossibleMoves(content);
                }

            });
        }

        public Piece getPiece() {
            return content;
        }
    }
