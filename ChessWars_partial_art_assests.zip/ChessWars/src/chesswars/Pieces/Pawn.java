package chesswars.Pieces;

import chesswars.Piece;
import chesswars.Position;

/**
 *
 * @author Michael
 */
public class Pawn extends Piece{
    private int movement;
    
    public Pawn(int r, int c, boolean isRed){
        super(c, r, isRed);
        
        if(isRed){
            movement = 1;
        }
        else{
            movement = -1;
        }
    }
    
    public void takeFirstMove(){
        firstMove = false;
    }
    
    public boolean testMove(Position p){
        Position pos = new Position(this.c, this.r);
        Position test = pos.getVector(p);

        if ((test.getR() == (-2 * movement) && test.getC() == 0) && (this.r == 1 || this.r == 6)){
            return true;
        }
        else if (test.getR() == (-1 * movement) && test.getC() == 0)
            return true;
        return false;
    }
}
