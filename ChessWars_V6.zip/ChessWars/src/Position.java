/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



public class Position {
    
    private int r;
    private int c;
    
    public Position(){
        
    }
    
    public Position(int c, int r){
        this.r = r;
        this.c = c;
    }
    
        public int getR(){
        return r;
    }
    
    public int getC(){
        return c;
    }
    
    public void setR(int r){
        this.r = r;
    }
    
    public void setC(int c){
        this.c = c;
    }
    
    public Position getVector(Position p1){
        Position temp = new Position(p1.c - c, p1.r - r);
        return temp;
    }
}
