

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * Controller class for the first vista.
 */
public class Chess1Controller {

    /**
     * Event handler fired when the user requests a new vista.
     *
     * @param startStage
     * @param event the event that triggered the handler.
     */
    
    public void start(Stage startStage) {
         AnchorPane root = new AnchorPane();
        root.setId("pane");
        Scene scene = new Scene(root,300,300);
        scene.getStylesheets().addAll(this.getClass().getResource("theme.css").toExternalForm());
        startStage.setScene(scene);
        startStage.show();
    }
    @FXML
    void nextPane(ActionEvent event) {
       
                
        ChessNavigator.loadChess(ChessNavigator.MULTIPLAYER);
    }

}