/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Michael
 */
public class Pawn extends Piece{
    
    public Pawn(int r, int c){
        super(c, r);
    }
    
        public boolean testMove(Position p){
        Position pos = new Position(this.c, this.r);
        Position test = pos.getVector(p);
        if (test.getR() == this.r && test.getC() == this.c)
            return false;
        else if (test.getR() == -1 && test.getC() == 0)
            return true;
        return false;
    }
    
}
